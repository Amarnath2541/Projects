from django.shortcuts import render
from .decorators import role_required

@role_required(allowed_roles=['Admin'])
def admin_dashboard(request):
    return render(request, 'myapp/admin_dashboard.html')

@role_required(allowed_roles=['Admin', 'Manager'])
def management_view(request):
    return render(request, 'myapp/management.html')

@role_required(allowed_roles=['Admin', 'Manager', 'Employee'])
def employee_dashboard(request):
    return render(request, 'myapp/employee_dashboard.html')

