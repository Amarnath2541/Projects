# myapp/urls.py
from django.urls import path
from . import views

urlpatterns = [
    # Add this line so visiting http://127.0.0.1:8000/ goes to the employee dashboard
    path('', views.employee_dashboard, name='home'), 
    
    path('admin-dash/', views.admin_dashboard, name='admin_dashboard'),
    path('management/', views.management_view, name='management_view'),
    path('employee-dash/', views.employee_dashboard, name='employee_dashboard'),
]