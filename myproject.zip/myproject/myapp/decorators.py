from django.http import HttpResponseForbidden
from functools import wraps
from .models import UserProfile

def role_required(allowed_roles=[]):  
    def decorator(view_func):
        @wraps(view_func)
        def wrapper(request, *args, **kwargs):
            if not request.user.is_authenticated:
                return HttpResponseForbidden("You must be logged in.")
            
            # Superusers automatically bypass restrictions
            if request.user.is_superuser:
                return view_func(request, *args, **kwargs)
                
            try:
                user_role = request.user.userprofile.role
                if user_role in allowed_roles:
                    return view_func(request, *args, **kwargs)
            except UserProfile.DoesNotExist:
                pass
                
            return HttpResponseForbidden("You do not have permission to view this page.")
        return wrapper
    return decorator
